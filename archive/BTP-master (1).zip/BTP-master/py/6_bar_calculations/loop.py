sum =0
for i in range(10):
    for j in range(10):
        for k in range(10):
            for l in range(10):
                sum=sum+1
print(sum)
