from crankshaft import *

for i in range(10,20):
    m = My_mechanism(i,50,20,14,2)
    try:
        m.velocity_params()
    except Exception:
        continue
