from six_bar import *
# (a,b,p,q,w)

m = My_mechanism(26,79,18,22,2)
# m.rod_p_position()
# m.animation_m()
m.animation_m_plus()
