from crankshaft import *
# (a,b,p,q,w)
# m = My_mechanism(10,20,10,15,2)
m = My_mechanism(22,50,20,14,2)
# m.rod_p_position()
# m.animation_m()
m.animation_m_plus()
