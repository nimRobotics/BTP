from six_bar import *
# (a,b,p,q,w)
# m = My_mechanism(10,20,10,15,2) 29	72	15	13
# m = My_mechanism(22,50,20,14,2)
# m = My_mechanism(29,72,15,13,2)
# m = My_mechanism(26,80,20,16,2) #btp
m = My_mechanism(26,74,18,19,2) #

# m.rod_p_position()
# m.animation_m()
m.animation_m_plus()
